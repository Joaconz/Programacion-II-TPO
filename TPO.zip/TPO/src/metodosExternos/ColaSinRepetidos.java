package metodosExternos;

import tda.ColaTDA;
import tda.ConjuntoTDA;
import imple.Cola;
import imple.Conjunto;

public class ColaSinRepetidos {

    public static ColaTDA resolver(ColaTDA cola) {
        ColaTDA aux = new Cola();
        aux.inicializarCola();

        ColaTDA resultado = new Cola();
        resultado.inicializarCola();

        ConjuntoTDA vistos = new Conjunto();
        vistos.inicializarConjunto();

        while (!cola.colaVacia()) {
            int x = cola.primero();
            cola.desacolar();

            if (!vistos.pertenece(x)) {
                resultado.acolar(x);
                vistos.agregar(x);
            }

            aux.acolar(x);
        }

        while (!aux.colaVacia()) {
            cola.acolar(aux.primero());
            aux.desacolar();
        }

        return resultado;
    }
}
