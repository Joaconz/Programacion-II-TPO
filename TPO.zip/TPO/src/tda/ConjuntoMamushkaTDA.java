package tda;

public interface ConjuntoMamushkaTDA {
    void inicializar();
    void guardar(int dato);
    void sacar(int dato);
    int elegir();
    int perteneceCant(int dato);
    boolean estaVacio();
}

