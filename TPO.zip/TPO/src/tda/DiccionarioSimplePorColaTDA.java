package tda;

import imple.ColaPrioridad;

public interface DiccionarioSimplePorColaTDA {
    // Esta interfaz mantiene la misma semántica que DiccionarioSimpleTDA
}

